"""ربات خبری ساعتی: جمع‌آوری از منابع معتبر -> تحلیل با Gemini (رایگان) یا Claude -> نوتیفیکیشن فارسی با ntfy"""
import calendar, hashlib, json, os, re, sys, time
import feedparser, requests

# ---------- تنظیمات ----------
FEEDS = {
    "BBC Persian": "https://feeds.bbci.co.uk/persian/rss.xml",
    "BBC Middle East": "https://feeds.bbci.co.uk/news/world/middle_east/rss.xml",
    "BBC World": "https://feeds.bbci.co.uk/news/world/rss.xml",
    "DW Persian": "https://rss.dw.com/rdf/rss-per-all",
    "Guardian": "https://www.theguardian.com/world/middleeast/rss",
    "Al Jazeera": "https://www.aljazeera.com/xml/rss/all.xml",
    "Times of Israel": "https://www.timesofisrael.com/feed/",
    "NPR": "https://feeds.npr.org/1004/rss.xml",
}
WINDOW_HOURS = 6          # خبرهای چند ساعت اخیر برای تطبیق چندمنبعی
MIN_SOURCES = int(os.getenv("MIN_SOURCES", "2"))   # حداقل منبع مستقل برای تأیید
MAX_NOTIFS = int(os.getenv("MAX_NOTIFS", "5"))     # سقف نوتیفیکیشن در هر اجرا
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
GEMINI_KEY = os.getenv("GEMINI_API_KEY", "")
NTFY_TOPIC = os.getenv("NTFY_TOPIC", "")
DRY_RUN = os.getenv("DRY_RUN") == "1"
STATE_FILE = "state.json"

PROMPT = """تو تحلیلگر ارشد خبر سیاسی و نظامی هستی. فهرست خبرهای زیر از منابع مختلف جمع‌آوری شده.

قوانین سخت:
1. فقط از همین فهرست استفاده کن. هیچ اطلاعات یا لینکی از خودت اضافه نکن.
2. خبرهای مربوط به یک رویداد را گروه‌بندی کن. هر رویداد را فقط وقتی بنویس که اهمیت سیاسی یا نظامی واقعی داشته باشد (نه سلبریتی، ورزش، اقتصاد خرد، سرگرمی).
3. در هر رویداد فقط منابعی را بیاور که واقعاً همان رویداد را گزارش کرده‌اند، با لینک دقیق از فهرست.
4. اگر منابع در جزئیات (مثلاً تعداد کشته‌ها) اختلاف دارند، در خلاصه ذکر کن.
5. ادعاهای یک طرف درگیری را به‌عنوان «ادعا» و با نام گوینده بنویس، نه به‌عنوان واقعیت.
6. عنوان و خلاصه (حداکثر ۳ جمله) کاملاً فارسی و روان باشد.
7. topic یکی از: iran, us, israel, other. اگر رویداد به ایران، آمریکا یا اسرائیل مربوط است همان را بگذار. importance عدد ۱ تا ۵.

خروجی فقط JSON معتبر و بدون هیچ متن اضافه، با این شکل:
{"events":[{"title_fa":"","summary_fa":"","topic":"iran","importance":3,"sources":[{"name":"","url":""}]}]}

خبرها:
"""

def clean(t):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", t or "")).strip()

def fetch_items():
    cutoff = time.time() - WINDOW_HOURS * 3600
    items = []
    for name, url in FEEDS.items():
        try:
            d = feedparser.parse(url, request_headers={"User-Agent": "Mozilla/5.0"})
            n = 0
            for e in d.entries[:50]:
                t = e.get("published_parsed") or e.get("updated_parsed")
                if not t or calendar.timegm(t) < cutoff:
                    continue
                items.append({"source": name, "title": clean(e.get("title")),
                              "summary": clean(e.get("summary"))[:300], "url": e.get("link", "")})
                n += 1
            print(f"[ok] {name}: {n} خبر")
        except Exception as ex:
            print(f"[خطا] {name}: {ex}")
    return items[:160]

def load_state():
    try:
        return set(json.load(open(STATE_FILE))["sent"])
    except Exception:
        return set()

def save_state(sent):
    json.dump({"sent": sorted(sent)[-1500:]}, open(STATE_FILE, "w"), ensure_ascii=False, indent=1)

def ask_llm(prompt):
    if GEMINI_KEY:  # رایگان
        r = requests.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent",
            headers={"x-goog-api-key": GEMINI_KEY},
            json={"contents": [{"parts": [{"text": prompt}]}],
                  "generationConfig": {"responseMimeType": "application/json", "temperature": 0.2}},
            timeout=120)
        r.raise_for_status()
        return r.json()["candidates"][0]["content"]["parts"][0]["text"]
    from anthropic import Anthropic  # پولی، اختیاری
    r = Anthropic().messages.create(model=MODEL, max_tokens=6000,
                                    messages=[{"role": "user", "content": prompt}])
    return r.content[0].text

def analyze(items):
    payload = "\n".join(f"- [{i['source']}] {i['title']} | {i['summary']} | {i['url']}" for i in items)
    text = ask_llm(PROMPT + payload).strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    return json.loads(text).get("events", [])

def verify(events, items):
    """رد لینک‌های ساختگی و اعمال شرط حداقل منبع مستقل"""
    valid = {i["url"]: i["source"] for i in items}
    good = []
    for ev in events:
        srcs, seen = [], set()
        for s in ev.get("sources", []):
            if s.get("url") in valid and valid[s["url"]] not in seen:
                seen.add(valid[s["url"]])
                srcs.append({"name": valid[s["url"]], "url": s["url"]})
        if len(srcs) >= MIN_SOURCES:
            ev["sources"] = srcs
            good.append(ev)
    return good

def rank(ev):
    pri = {"iran": 0, "israel": 0, "us": 0}.get(ev.get("topic"), 1)
    return (pri, -int(ev.get("importance", 1)))

def notify(ev):
    body = ev["summary_fa"] + "\n\nمنابع: " + "، ".join(s["name"] for s in ev["sources"])
    tags = {"iran": "flag-ir", "israel": "flag-il", "us": "flag-us"}.get(ev.get("topic"), "globe_with_meridians")
    msg = {"topic": NTFY_TOPIC, "title": ev["title_fa"], "message": body,
           "priority": 4 if int(ev.get("importance", 1)) >= 4 else 3,
           "tags": [tags], "click": ev["sources"][0]["url"],
           "actions": [{"action": "view", "label": s["name"], "url": s["url"]} for s in ev["sources"][:3]]}
    if DRY_RUN:
        print(json.dumps(msg, ensure_ascii=False, indent=1)); return
    requests.post("https://ntfy.sh", json=msg, timeout=20).raise_for_status()

def main():
    if not NTFY_TOPIC and not DRY_RUN:
        sys.exit("NTFY_TOPIC تنظیم نشده")
    items = fetch_items()
    if not items:
        print("خبری نبود"); return
    sent = load_state()
    events = verify(analyze(items), items)
    fresh = [e for e in events if any(s["url"] not in sent for s in e["sources"])]
    fresh.sort(key=rank)
    for ev in fresh[:MAX_NOTIFS]:
        notify(ev)
        sent.update(s["url"] for s in ev["sources"])
        time.sleep(1)
    # رویدادهای باقی‌مانده بعد از سقف، دوباره در اجرای بعد بررسی می‌شوند
    print(f"ارسال شد: {min(len(fresh), MAX_NOTIFS)} از {len(fresh)}")
    save_state(sent)

if __name__ == "__main__":
    main()
